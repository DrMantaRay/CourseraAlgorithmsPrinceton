/**
 * Created by pchen on 2/5/2017.
 */
import java.util.Arrays;
import java.util.ArrayList;

public class FastCollinearPoints {
    private int numberOfSegments;
    private ArrayList<LineSegment> segments;
    public FastCollinearPoints(Point[] points) {
        if (points == null)
        { throw new NullPointerException(); }
        Arrays.sort(points, Point::compareTo);
        for (int i = 0; i < points.length; i++ ) {
            if (points[i] == null) { throw new NullPointerException(); }
            if (i < points.length-1) {
                if (points[i] == points[i+1]) {
                    throw new IllegalArgumentException();
                }
            }
        }



    }
    public int numberOfSegments() {
        return numberOfSegments;
    }
    public LineSegment[] segments() {
        return segments.toArray(new LineSegment[segments.size()]);
    }
}
