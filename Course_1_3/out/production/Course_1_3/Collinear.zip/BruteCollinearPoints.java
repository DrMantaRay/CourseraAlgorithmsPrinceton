/**
 * Created by pchen on 2/5/2017.
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class BruteCollinearPoints {
    private int numberOfSegments;
    private ArrayList<LineSegment> segments;
    private boolean fourOnline(Point a, Point b, Point c, Point d) {
        return a.slopeTo(b) == a.slopeTo(c) && a.slopeTo(b) == a.slopeTo(d);
    }
    public BruteCollinearPoints(Point[] points) {
        if (points == null)
        { throw new NullPointerException(); }
        Arrays.sort(points, Point::compareTo);
        for (int i = 0; i < points.length; i++ ) {
            if (points[i] == null) { throw new NullPointerException(); }
            if (i < points.length-1) {
                if (points[i] == points[i+1]) {
                    throw new IllegalArgumentException();
                }
            }
        }
        for (int i=0; i < points.length; i++) {
            for (int j = i+1; j < points.length; j++) {
                for (int k = j+1; k < points.length; k++) {
                    for (int l = k+1; l < points.length; l++ ) {
                        if (fourOnline(points[i], points[j], points[k], points[l])) {
                            numberOfSegments++;
                            Point[] s = new Point[4];
                            s[0] = points[i];
                            s[1] = points[j];
                            s[2] = points[k];
                            s[3] = points[l];
                            Arrays.sort(s, Point::compareTo);
                            segments.add(new LineSegment(s[0],s[3]));
                        }
                    }
                }
            }
        }
    }
    public int numberOfSegments() {
        return numberOfSegments;
    }
    public LineSegment[] segments() {
        return segments.toArray(new LineSegment[segments.size()]);
    }
}
