

import edu.princeton.cs.algs4.WeightedQuickUnionUF;
import java.lang.IllegalArgumentException;

public class Percolation {
    private int[][] matrix;
    private int dim;
    private int numOpenSites = 0;
    public int numberOfOpenSites() {
        return numOpenSites;
    }
    private boolean isInBounds(int row, int col) throws IndexOutOfBoundsException {
        return (row>=1 && col>=1 && row <= dim && col <= dim );
    }
    public Percolation(int n) throws IllegalArgumentException {
        if (n<=0) {
            throw new IllegalArgumentException("n must be less than or equal to 0");
        }
        dim= n;
        matrix= new int[dim][dim];
    }
    public void open(int row, int col) throws IndexOutOfBoundsException {
        if (isInBounds(col,row)) {
            matrix[col - 1][row - 1] = 1;
            numOpenSites++;
        }
        else {throw new IndexOutOfBoundsException
                ("row and column must be greater than 0 and less than or equal to dimension");}
    }
    public boolean isOpen(int row, int col) throws IndexOutOfBoundsException {
        if (isInBounds(col, row)) {
            return matrix[col-1][row-1]==1;
        } else {throw new IndexOutOfBoundsException();}
    }
    public boolean isFull(int row, int col) {
        return !isOpen(row,col);
    };
    private int coordToArrayInt(int i, int j) {
        return dim*(j-1)+i;
    }
    public boolean percolates() {
        WeightedQuickUnionUF sites= new WeightedQuickUnionUF(dim*dim+2);
        for (int i=1;i<=dim;i++) {
            sites.union(0,i);
            sites.union(dim*dim+1,dim*dim+1-i);
        }
        for (int i=1;i<=dim;i++) {
            for (int j=1;j<=dim;j++) {
                if (this.isOpen(i,j)) {
                    if (i - 1 >= 1 && this.isOpen(i-1,j)) {
                         sites.union(coordToArrayInt(i,j),coordToArrayInt(i-1,j));
                    }
                    if (i+1 <= dim && this.isOpen(i+1,j)) {
                        sites.union(coordToArrayInt(i,j),coordToArrayInt(i+1,j));
                    }
                    if (j-1>= 1 && this.isOpen(i,j-1)) {
                        sites.union(coordToArrayInt(i,j),coordToArrayInt(i,j-1));
                    }
                    if (j+1<= dim && this.isOpen(i,j+1)) {
                        sites.union(coordToArrayInt(i,j),coordToArrayInt(i,j+1));
                    }
                }
            }
        }
        return sites.connected(0,dim*dim+1);
    }
    public static void main (String[] args) {

    }
}